// AVR HW-spcific Functions
#ifdef ARDUINO_ARCH_AVR
#include <Arduino.h>
#include "drivers.h"

//#warning "HW specfic - avr ---"
#endif